package com.example.sleep_tracker

import android.app.TimePickerDialog
import android.content.SharedPreferences
import android.os.Bundle
import android.os.SystemClock
import android.widget.*
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    lateinit var chronometer: Chronometer
    lateinit var sleepStage: TextView
    lateinit var avgSleep: TextView

    var startTime: Long = 0
    var running = false
    var goalHours = 8

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        chronometer = findViewById(R.id.chronometer)
        sleepStage = findViewById(R.id.sleepStage)
        avgSleep = findViewById(R.id.avgSleep)

        val startBtn = findViewById<Button>(R.id.startBtn)
        val stopBtn = findViewById<Button>(R.id.stopBtn)
        val resetBtn = findViewById<Button>(R.id.resetBtn)
        val settingsBtn = findViewById<Button>(R.id.settingsBtn)

        val prefs = getSharedPreferences("sleepData", MODE_PRIVATE)

        updateAverage(prefs)

        startBtn.setOnClickListener {

            if (!running) {

                startTime = System.currentTimeMillis()

                chronometer.base = SystemClock.elapsedRealtime()
                chronometer.start()

                running = true

                sleepStage.text = "Sleep Stage: Light Sleep"
            }
        }

        stopBtn.setOnClickListener {

            if (!running) {
                Toast.makeText(this, "Tracking not started", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            chronometer.stop()
            running = false

            val endTime = System.currentTimeMillis()
            val duration = endTime - startTime

            val hours = duration / (1000 * 60 * 60)

            saveSleep(prefs, hours)

            checkGoal(hours)

            updateAverage(prefs)
        }

        resetBtn.setOnClickListener {

            chronometer.base = SystemClock.elapsedRealtime()
            chronometer.stop()

            sleepStage.text = "Sleep Stage: Awake"

            running = false
        }

        settingsBtn.setOnClickListener {

            val picker = TimePickerDialog(
                this,
                { _, hour, _ -> goalHours = hour },
                goalHours,
                0,
                true
            )

            picker.show()
        }

        chronometer.setOnChronometerTickListener {

            val elapsed = SystemClock.elapsedRealtime() - chronometer.base
            val seconds = elapsed / 1000

            if (seconds >= 15) {
                sleepStage.text = "Sleep Stage: Deep Sleep"
            } else {
                sleepStage.text = "Sleep Stage: Light Sleep"
            }
        }
    }

    fun saveSleep(prefs: SharedPreferences, hours: Long) {

        val total = prefs.getLong("totalSleep", 0)
        val days = prefs.getLong("days", 0)

        prefs.edit()
            .putLong("totalSleep", total + hours)
            .putLong("days", days + 1)
            .apply()
    }

    fun updateAverage(prefs: SharedPreferences) {

        val total = prefs.getLong("totalSleep", 0)
        val days = prefs.getLong("days", 0)

        if (days > 0) {
            val avg = total / days
            avgSleep.text = "Average Sleep: $avg h"
        }
    }

    fun checkGoal(hours: Long) {

        if (hours < goalHours) {

            Toast.makeText(
                this,
                "You slept ${goalHours - hours}h less than your goal",
                Toast.LENGTH_LONG
            ).show()

        } else {

            Toast.makeText(
                this,
                "Goal achieved! Good sleep",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}